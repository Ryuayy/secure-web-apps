
# 📘 Secure Web App - UTS Rekayasa Perangkat Lunak Lanjutan

## 👩‍🎓 Nama: Sri Rahayu  
## 🆔 NIM: 2023140074  

Aplikasi web ini dibuat menggunakan Django dan Django REST Framework (DRF) untuk memenuhi Ujian Tengah Semester mata kuliah Rekayasa Perangkat Lunak Lanjutan. Fokus utama adalah keamanan aplikasi berbasis API menggunakan hashing, JWT authentication, dan anti-SQL injection.

---

## 🔐 Fitur Keamanan

- ✅ **Password hashing**: Menggunakan sistem hashing bawaan Django (`PBKDF2`).
- ✅ **Proteksi dari SQL Injection**: Semua query dilakukan dengan Django ORM.
- ✅ **Token-based Authentication**: Menggunakan JWT (JSON Web Token) untuk login dan otorisasi akses API.
- ✅ **Validasi Input**: Semua input divalidasi melalui serializer DRF.

---

## 🛠️ Instalasi Aplikasi

1. Clone repo:
```bash
git clone https://github.com/Ryuayy/secure-web-app.git
cd secure-web-app
```

2. Install dependency:
```bash
pip install -r requirements.txt
```

3. Jalankan migrasi database:
```bash
python manage.py makemigrations
python manage.py migrate
```

4. Jalankan server:
```bash
python manage.py runserver
```

---

## 📂 Struktur Folder

```
secure-web-app/
├── manage.py
├── requirements.txt
├── README.md
└── core/
    ├── models.py         # Model user kustom
    ├── serializers.py    # Validasi input & konversi data
    ├── views.py          # Logika backend API
    ├── urls.py           # Rute URL lokal app
```

---

## 🔎 Penjelasan Kode

### 📄 models.py
```python
class CustomUser(AbstractUser):
    email = models.EmailField(unique=True)
```
Menggunakan `AbstractUser` untuk membuat user kustom dengan email unik.

### 📄 serializers.py
Validasi dan membuat user dengan password yang di-hash otomatis.

### 📄 views.py
`RegisterView` menerima POST user baru. `ProfileView` hanya bisa diakses dengan token JWT.

### 📄 urls.py
Routing app-level: `/register/`, `/profile/`

---

## 🌐 URL Routing Project Utama

Tambahkan ke `secure_web_app/urls.py`:
```python
from django.urls import path, include
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('core.urls')),
    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]
```

---

## 🔑 Pengujian API (Postman)

### ✅ Register
- `POST /register/`
```json
{
  "username": "sri",
  "email": "sri@example.com",
  "password": "password123"
}
```

### 🔐 Login (Token)
- `POST /token/`
```json
{
  "username": "sri",
  "password": "password123"
}
```

### 👤 Get Profile
- `GET /profile/`  
Tambahkan header:
```
Authorization: Bearer <access_token>
```

---

## 📌 Catatan Tambahan

- Semua input tervalidasi
- Tidak menggunakan raw SQL
- Semua API aman dari SQL Injection
- Token JWT disimpan di client (Postman)

---

## 📄 Lisensi
Hak Cipta © 2025 oleh Sri Rahayu - Universitas XYZ. Untuk keperluan akademik.

