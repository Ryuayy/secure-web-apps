
# urls.py (app-level)
# Rute endpoint untuk API yang disediakan oleh app "core"

from django.urls import path
from .views import RegisterView, ProfileView

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('profile/', ProfileView.as_view(), name='profile'),
]
