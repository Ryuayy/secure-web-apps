
# serializers.py
# Konversi data antara model dan JSON (API layer)

from rest_framework import serializers
from django.contrib.auth import get_user_model

class RegisterSerializer(serializers.ModelSerializer):
    class Meta:
        model = get_user_model()
        fields = ('username', 'email', 'password')
        extra_kwargs = {'password': {'write_only': True}}  # Password hanya bisa ditulis, tidak ditampilkan

    def create(self, validated_data):
        # Membuat user baru dengan password yang di-hash otomatis
        user = get_user_model().objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            password=validated_data['password']
        )
        return user
